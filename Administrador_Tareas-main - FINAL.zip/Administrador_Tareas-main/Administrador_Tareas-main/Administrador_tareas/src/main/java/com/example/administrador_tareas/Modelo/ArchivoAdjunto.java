package com.example.administrador_tareas.Modelo;

import java.time.LocalDateTime;

public class ArchivoAdjunto {
    private Long idArchivo;
    private Long idTarea;
    private String nombreArchivo;
    private String rutaArchivo; // Maps to ruta_archivo
    private String tipoMime; // Maps to tipo_mime
    private boolean esImagen; // Maps to es_imagen
    private Long subidoPor;
    private LocalDateTime fechaSubida;

    public ArchivoAdjunto() {
    }

    public ArchivoAdjunto(Long idArchivo, Long idTarea, String nombreArchivo, String rutaArchivo, String tipoMime,
            boolean esImagen, Long subidoPor) {
        this.idArchivo = idArchivo;
        this.idTarea = idTarea;
        this.nombreArchivo = nombreArchivo;
        this.rutaArchivo = rutaArchivo;
        this.tipoMime = tipoMime;
        this.esImagen = esImagen;
        this.subidoPor = subidoPor;
        this.fechaSubida = LocalDateTime.now();
    }

    public Long getIdArchivo() {
        return idArchivo;
    }

    public void setIdArchivo(Long idArchivo) {
        this.idArchivo = idArchivo;
    }

    public Long getIdTarea() {
        return idTarea;
    }

    public void setIdTarea(Long idTarea) {
        this.idTarea = idTarea;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getTipoMime() {
        return tipoMime;
    }

    public void setTipoMime(String tipoMime) {
        this.tipoMime = tipoMime;
    }

    public boolean isEsImagen() {
        return esImagen;
    }

    public void setEsImagen(boolean esImagen) {
        this.esImagen = esImagen;
    }

    public Long getSubidoPor() {
        return subidoPor;
    }

    public void setSubidoPor(Long subidoPor) {
        this.subidoPor = subidoPor;
    }

    public LocalDateTime getFechaSubida() {
        return fechaSubida;
    }

    public void setFechaSubida(LocalDateTime fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    // Compatibility methods if needed
    public String getRuta() {
        return rutaArchivo;
    }

    public void setRuta(String ruta) {
        this.rutaArchivo = ruta;
    }

    public String getTipo() {
        return tipoMime;
    }

    public void setTipo(String tipo) {
        this.tipoMime = tipo;
    }
}
