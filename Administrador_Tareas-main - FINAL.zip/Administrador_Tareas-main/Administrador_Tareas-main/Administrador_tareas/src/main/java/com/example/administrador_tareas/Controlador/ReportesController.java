package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ArchivoAdjuntoDAO;
import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Modelo.ArchivoAdjunto;
import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ReportesController {

    @FXML
    private Label lblTotalCompletadas;
    @FXML
    private Label lblTasaExito;
    @FXML
    private Label lblPromedioDias;
    @FXML
    private PieChart pieChartEstado;
    @FXML
    private BarChart<String, Number> barChartPrioridad;
    @FXML
    private VBox vboxRendimientoEquipos;

    private Usuario usuarioActual;
    private TareaDAO tareaDAO;
    private EquipoDAO equipoDAO;
    private ArchivoAdjuntoDAO archivoAdjuntoDAO;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.tareaDAO = new TareaDAO();
        this.equipoDAO = new EquipoDAO();
        this.archivoAdjuntoDAO = new ArchivoAdjuntoDAO();
        cargarDatos();
        cargarRendimientoEquipos();
    }

    private void cargarDatos() {
        if (usuarioActual == null)
            return;

        try {
            List<Tarea> tareas = tareaDAO.listarPorUsuario(usuarioActual.getIdUsuario());

            // KPIs
            long completadas = tareas.stream().filter(t -> t.getEstado() == EstadoTarea.COMPLETED).count();
            long total = tareas.size();
            double tasaExito = total > 0 ? (double) completadas / total * 100 : 0;

            lblTotalCompletadas.setText(String.valueOf(completadas));
            lblTasaExito.setText(String.format("%.1f%%", tasaExito));

            // Placeholder for average days (requires creation/completion dates)
            lblPromedioDias.setText("2.5");

            // Pie Chart - Status
            Map<EstadoTarea, Long> statusCounts = tareas.stream()
                    .collect(Collectors.groupingBy(Tarea::getEstado, Collectors.counting()));

            ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
            statusCounts.forEach((status, count) -> pieData.add(new PieChart.Data(status.name(), count)));
            pieChartEstado.setData(pieData);

            // Bar Chart - Priority
            Map<com.example.administrador_tareas.Modelo.PrioridadTarea, Long> priorityCounts = tareas.stream()
                    .collect(Collectors.groupingBy(Tarea::getPrioridad, Collectors.counting()));

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Tareas");
            priorityCounts
                    .forEach((priority, count) -> series.getData().add(new XYChart.Data<>(priority.name(), count)));
            barChartPrioridad.getData().clear();
            barChartPrioridad.getData().add(series);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta(Alert.AlertType.ERROR, "Error", "Error al cargar reportes: " + e.getMessage());
        }
    }

    private void cargarRendimientoEquipos() {
        vboxRendimientoEquipos.getChildren().clear();
        List<Equipo> equipos = equipoDAO.listarEquiposPorUsuario(usuarioActual.getIdUsuario());

        if (equipos.isEmpty()) {
            Label lblEmpty = new Label("No perteneces a ningún equipo.");
            lblEmpty.setStyle("-fx-text-fill: #64748B; -fx-font-style: italic;");
            vboxRendimientoEquipos.getChildren().add(lblEmpty);
            return;
        }

        for (Equipo equipo : equipos) {
            VBox teamSection = new VBox(10);
            teamSection.setStyle(
                    "-fx-background-color: white; -fx-padding: 15; -fx-background-radius: 8; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 5, 0, 0, 2);");

            Label lblTeamName = new Label(equipo.getNombre());
            lblTeamName.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");
            teamSection.getChildren().add(lblTeamName);

            List<Usuario> miembros = equipoDAO.listarMiembros(equipo.getIdEquipo());
            for (Usuario miembro : miembros) {
                VBox memberCard = new VBox(10);
                memberCard.setStyle(
                        "-fx-background-color: #F8FAFC; -fx-padding: 10; -fx-background-radius: 6; -fx-border-color: #E2E8F0; -fx-border-width: 1;");

                // Member Header
                HBox header = new HBox(10);
                header.setAlignment(Pos.CENTER_LEFT);

                Circle avatar = new Circle(15, Color.LIGHTGRAY);
                if (miembro.getRutaImagen() != null && !miembro.getRutaImagen().isEmpty()
                        && new File(miembro.getRutaImagen()).exists()) {
                    avatar.setFill(new javafx.scene.paint.ImagePattern(
                            new javafx.scene.image.Image(new File(miembro.getRutaImagen()).toURI().toString())));
                }

                Label lblName = new Label(miembro.getNombre());
                lblName.setStyle("-fx-font-weight: bold; -fx-text-fill: #334155;");

                header.getChildren().addAll(avatar, lblName);

                // Stats
                List<Tarea> tareas = tareaDAO.listarTareasPorUsuarioYEquipo(miembro.getIdUsuario(),
                        equipo.getIdEquipo());
                long completed = tareas.stream().filter(t -> t.getEstado() == EstadoTarea.COMPLETED).count();
                long total = tareas.size();
                double progress = total > 0 ? (double) completed / total : 0;

                HBox statsBox = new HBox(10);
                statsBox.setAlignment(Pos.CENTER_LEFT);
                ProgressBar progressBar = new ProgressBar(progress);
                progressBar.setPrefWidth(150);
                Label lblProgress = new Label(String.format("%.0f%% (%d/%d tareas)", progress * 100, completed, total));
                lblProgress.setStyle("-fx-font-size: 11px; -fx-text-fill: #64748B;");
                statsBox.getChildren().addAll(progressBar, lblProgress);

                // Task Cards
                FlowPane tasksPane = new FlowPane();
                tasksPane.setHgap(10);
                tasksPane.setVgap(10);

                for (Tarea tarea : tareas) {
                    VBox taskCard = new VBox(5);
                    taskCard.setPrefWidth(120);
                    taskCard.setStyle(
                            "-fx-background-color: white; -fx-padding: 8; -fx-background-radius: 4; -fx-border-color: #CBD5E1; -fx-cursor: hand;");

                    Label lblTitle = new Label(tarea.getTitulo());
                    lblTitle.setWrapText(true);
                    lblTitle.setStyle("-fx-font-size: 11px; -fx-font-weight: bold;");

                    Label lblStatus = new Label(tarea.getEstado().name());
                    String statusColor = tarea.getEstado() == EstadoTarea.COMPLETED ? "#166534" : "#1E40AF";
                    String statusBg = tarea.getEstado() == EstadoTarea.COMPLETED ? "#DCFCE7" : "#DBEAFE";
                    lblStatus.setStyle("-fx-background-color: " + statusBg + "; -fx-text-fill: " + statusColor
                            + "; -fx-padding: 2 4; -fx-background-radius: 3; -fx-font-size: 9px;");

                    taskCard.getChildren().addAll(lblTitle, lblStatus);
                    taskCard.setOnMouseClicked(e -> abrirAdjunto(tarea));

                    tasksPane.getChildren().add(taskCard);
                }

                memberCard.getChildren().addAll(header, statsBox, tasksPane);
                teamSection.getChildren().add(memberCard);
            }
            vboxRendimientoEquipos.getChildren().add(teamSection);
        }
    }

    private void abrirAdjunto(Tarea tarea) {
        try {
            List<ArchivoAdjunto> adjuntos = archivoAdjuntoDAO.listarPorTarea(tarea.getIdTarea());
            if (adjuntos.isEmpty()) {
                mostrarAlerta(Alert.AlertType.INFORMATION, "Sin Archivos", "Esta tarea no tiene archivos adjuntos.");
                return;
            }

            // Open the first attachment
            ArchivoAdjunto adjunto = adjuntos.get(0);
            File file = new File(adjunto.getRutaArchivo());
            if (file.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(file);
                } else {
                    mostrarAlerta(Alert.AlertType.WARNING, "No soportado",
                            "El sistema no soporta abrir archivos automáticamente.");
                }
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "Error", "El archivo no existe en la ruta especificada.");
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            mostrarAlerta(Alert.AlertType.ERROR, "Error", "No se pudo abrir el archivo: " + e.getMessage());
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handleExportarPDF(ActionEvent event) {
        mostrarAlerta(Alert.AlertType.INFORMATION, "Exportar Reporte", "Funcionalidad de exportar a PDF próximamente.");
    }
}
