package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ArchivoAdjuntoDAO;
import com.example.administrador_tareas.Dao.ComentarioDAO;
import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.io.File;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class DetalleTareaController {

    @FXML
    private TextField txtTitulo;
    @FXML
    private TextArea txtDescripcion;
    // @FXML private ComboBox<EstadoTarea> cmbEstado; // Removed
    @FXML
    private ComboBox<PrioridadTarea> cmbPrioridad;
    @FXML
    private DatePicker dpFechaLimite;
    @FXML
    private Label lblAsignado;
    @FXML
    private VBox vboxComentarios;
    @FXML
    private TextArea txtNuevoComentario;
    @FXML
    private VBox vboxAdjuntos;
    @FXML
    private Button btnCerrar;

    private Tarea tarea;
    private Usuario usuarioActual;
    private boolean guardado = false;

    public void setDatos(Tarea tarea, Usuario usuario) {
        this.tarea = tarea;
        this.usuarioActual = usuario;
        cargarDatos();
    }

    private void cargarDatos() {
        if (tarea == null)
            return;

        String titulo = tarea.getTitulo();
        if (titulo != null && !titulo.isEmpty()) {
            titulo = titulo.substring(0, 1).toUpperCase() + titulo.substring(1);
        }
        txtTitulo.setText(titulo);
        txtDescripcion.setText(tarea.getDescripcion());

        cmbPrioridad.getItems().setAll(PrioridadTarea.values());
        cmbPrioridad.setValue(tarea.getPrioridad());
        cmbPrioridad.setConverter(new StringConverter<PrioridadTarea>() {
            @Override
            public String toString(PrioridadTarea object) {
                if (object == null)
                    return "";
                switch (object) {
                    case LOW:
                        return "Baja";
                    case MEDIUM:
                        return "Media";
                    case HIGH:
                        return "Alta";
                    case URGENT:
                        return "Urgente";
                    default:
                        return object.name();
                }
            }

            @Override
            public PrioridadTarea fromString(String string) {
                return null;
            }
        });

        if (tarea.getFechaLimite() != null) {
            dpFechaLimite.setValue(tarea.getFechaLimite().toLocalDate());
        }

        // Placeholder for assignee name, ideally we fetch it or pass it
        lblAsignado.setText(usuarioActual.getNombre());

        cargarComentarios();
        cargarAdjuntos();
    }

    @FXML
    private void handleGuardar() {
        tarea.setTitulo(txtTitulo.getText());
        tarea.setDescripcion(txtDescripcion.getText());
        // tarea.setEstado(cmbEstado.getValue()); // Removed
        tarea.setPrioridad(cmbPrioridad.getValue());
        if (dpFechaLimite.getValue() != null) {
            tarea.setFechaLimite(dpFechaLimite.getValue().atTime(23, 59));
        } else {
            tarea.setFechaLimite(null);
        }

        try {
            new TareaDAO().actualizar(tarea);
            guardado = true;
            new Alert(Alert.AlertType.INFORMATION, "Cambios guardados.").showAndWait();
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Error al guardar.").show();
        }
    }

    @FXML
    private void handleArchivar() {
        try {
            new TareaDAO().actualizarEstado(tarea.getIdTarea(), EstadoTarea.ARCHIVED);
            guardado = true;
            cerrarVentana();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEliminar() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Estás seguro de eliminar esta tarea?");
        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            try {
                new TareaDAO().eliminarLogico(tarea.getIdTarea());
                guardado = true;
                cerrarVentana();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleCerrar() {
        cerrarVentana();
    }

    private void cerrarVentana() {
        Stage stage = (Stage) txtTitulo.getScene().getWindow();
        stage.close();
    }

    // --- Comentarios ---

    private void cargarComentarios() {
        vboxComentarios.getChildren().clear();
        try {
            List<Comentario> comentarios = new ComentarioDAO().listarPorTarea(tarea.getIdTarea());
            for (Comentario c : comentarios) {
                VBox bubble = new VBox(5);
                bubble.setStyle("-fx-background-color: #F1F5F9; -fx-padding: 10; -fx-background-radius: 8;");

                Label lblUser = new Label(c.getNombreUsuario() + " - "
                        + c.getFechaCreacion().format(DateTimeFormatter.ofPattern("dd/MM HH:mm")));
                lblUser.setStyle("-fx-font-weight: bold; -fx-font-size: 10px; -fx-text-fill: #64748B;");

                Label lblContent = new Label(c.getContenido());
                lblContent.setWrapText(true);

                bubble.getChildren().addAll(lblUser, lblContent);
                vboxComentarios.getChildren().add(bubble);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEnviarComentario() {
        if (txtNuevoComentario.getText().trim().isEmpty())
            return;

        Comentario nuevo = new Comentario();
        nuevo.setIdTarea(tarea.getIdTarea());
        nuevo.setIdUsuario(usuarioActual.getIdUsuario());
        nuevo.setContenido(txtNuevoComentario.getText().trim());

        try {
            new ComentarioDAO().insertar(nuevo);
            txtNuevoComentario.clear();
            cargarComentarios();

            // Notification for new comment
            // Notify task creator if it's not the current user
            if (!tarea.getCreadoPor().equals(usuarioActual.getIdUsuario())) {
                AlertaDAO alertaDAO = new AlertaDAO();
                String msg = "Nuevo comentario en tu tarea '" + tarea.getTitulo() + "': " + nuevo.getContenido();
                // Truncate message if too long
                if (msg.length() > 250)
                    msg = msg.substring(0, 247) + "...";
                alertaDAO.crear(new Alerta(tarea.getCreadoPor(), TipoAlerta.NEW_COMMENT, msg));
            }
            // Also notify other participants (omitted for simplicity, would need to fetch
            // unique commenters)
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // --- Adjuntos ---

    private void cargarAdjuntos() {
        vboxAdjuntos.getChildren().clear();
        try {
            List<ArchivoAdjunto> adjuntos = new ArchivoAdjuntoDAO().listarPorTarea(tarea.getIdTarea());
            for (ArchivoAdjunto adj : adjuntos) {
                HBox row = new HBox(10);
                row.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

                Label lblName = new Label(adj.getNombreArchivo());
                lblName.setStyle("-fx-font-weight: bold;");

                Button btnDownload = new Button("⬇");
                btnDownload.setOnAction(e -> {
                    new Alert(Alert.AlertType.INFORMATION, "Descargar: " + adj.getRutaArchivo()).show();
                });

                row.getChildren().addAll(lblName, btnDownload);
                vboxAdjuntos.getChildren().add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSubirArchivo() {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(txtTitulo.getScene().getWindow());
        if (file != null) {
            try {
                ArchivoAdjunto archivo = new ArchivoAdjunto();
                archivo.setIdTarea(tarea.getIdTarea());
                archivo.setNombreArchivo(file.getName());
                archivo.setRutaArchivo(file.getAbsolutePath());
                archivo.setSubidoPor(usuarioActual.getIdUsuario());

                // Simple mime type check
                String name = file.getName().toLowerCase();
                if (name.endsWith(".png") || name.endsWith(".jpg")) {
                    archivo.setTipoMime("image/jpeg");
                    archivo.setEsImagen(true);
                } else {
                    archivo.setTipoMime("application/octet-stream");
                    archivo.setEsImagen(false);
                }

                new ArchivoAdjuntoDAO().insertar(archivo);
                cargarAdjuntos();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isGuardado() {
        return guardado;
    }
}
