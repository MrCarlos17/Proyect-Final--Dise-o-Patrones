package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.Rol;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RolDAO {

    public List<Rol> listarRoles() {
        List<Rol> roles = new ArrayList<>();
        String sql = "SELECT * FROM roles";

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Rol rol = new Rol();
                rol.setIdRol(rs.getLong("id_rol"));
                rol.setNombre(rs.getString("nombre"));
                rol.setDescripcion(rs.getString("descripcion"));
                rol.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                rol.setFechaActualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
                roles.add(rol);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return roles;
    }

    public Rol obtenerRolPorId(Long idRol) {
        String sql = "SELECT * FROM roles WHERE id_rol = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, idRol);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Rol rol = new Rol();
                    rol.setIdRol(rs.getLong("id_rol"));
                    rol.setNombre(rs.getString("nombre"));
                    rol.setDescripcion(rs.getString("descripcion"));
                    rol.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                    rol.setFechaActualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
                    return rol;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
