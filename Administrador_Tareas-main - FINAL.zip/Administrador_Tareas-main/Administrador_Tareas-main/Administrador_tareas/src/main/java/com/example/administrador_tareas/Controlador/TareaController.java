package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Modelo.TipoAlerta;
import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Modelo.Proyecto;
import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Dao.ProyectoDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TareaController {
    @FXML
    private Button btnInicio;
    @FXML
    private Button btnPanelControl;
    @FXML
    private Button btnMisTareas;
    @FXML
    private Button btnProyectos;
    @FXML
    private Button btnReportes;
    @FXML
    private Button btnEquipos;
    @FXML
    private Button btnAjustes;
    @FXML
    private Button btnArchivados;
    @FXML
    private Label lblNombreUsuario;
    @FXML
    private VBox vboxPendientes;
    @FXML
    private VBox vboxProgreso;
    @FXML
    private VBox vboxCompletadas;
    @FXML
    private Label lblCountPendientes;
    @FXML
    private Label lblCountProgreso;
    @FXML
    private Label lblCountCompletadas;
    @FXML
    private Button btnNuevaTarea;
    @FXML
    private Button btnSalir;
    @FXML
    private Button btnNotificaciones;
    @FXML
    private TextField searchField;
    @FXML
    private Button btnRangoFecha;
    @FXML
    private ComboBox<Equipo> comboEquipos;
    @FXML
    private ComboBox<Proyecto> comboProyectos;
    @FXML
    private Button btnHoy;
    @FXML
    private Button btnTodas;
    @FXML
    private Button btnVencidas;

    private boolean filtroHoy = false;
    private boolean filtroVencidas = false;

    private java.time.LocalDate fechaInicioFilter;
    private java.time.LocalDate fechaFinFilter;

    private Usuario usuarioActual;
    private List<Tarea> listaTareas = new ArrayList<>();
    private javafx.scene.Node kanbanView;
    @FXML
    private javafx.scene.layout.BorderPane mainBorderPane;
    @FXML
    private javafx.scene.layout.BorderPane contentBorderPane;

    @FXML
    private javafx.scene.shape.Circle headerAvatar;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        lblNombreUsuario.setText(usuario.getNombre());
        actualizarAvatarHeader();
        actualizarAvatarHeader();
        recargarTareasDesdeBD();
        verificarNotificacionesSistema();
    }

    private void verificarNotificacionesSistema() {
        if (usuarioActual == null)
            return;

        AlertaDAO alertaDAO = new AlertaDAO();

        // 1. Deadline Check (Days remaining)
        for (Tarea tarea : listaTareas) {
            if (tarea.getEstado() != EstadoTarea.COMPLETED && tarea.getFechaLimite() != null) {
                long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(),
                        tarea.getFechaLimite().toLocalDate());
                if (daysBetween >= 0 && daysBetween <= 3) {
                    String msg = "La tarea '" + tarea.getTitulo() + "' vence en " + daysBetween + " días.";
                    if (daysBetween == 0)
                        msg = "La tarea '" + tarea.getTitulo() + "' vence hoy.";

                    if (!alertaDAO.existeAlertaReciente(usuarioActual.getIdUsuario(), TipoAlerta.DEADLINE, msg)) {
                        alertaDAO.crear(new Alerta(usuarioActual.getIdUsuario(), TipoAlerta.DEADLINE, msg));
                    }
                } else if (daysBetween < 0) {
                    String msg = "La tarea '" + tarea.getTitulo() + "' está vencida por " + Math.abs(daysBetween)
                            + " días.";
                    if (!alertaDAO.existeAlertaReciente(usuarioActual.getIdUsuario(), TipoAlerta.DEADLINE, msg)) {
                        alertaDAO.crear(new Alerta(usuarioActual.getIdUsuario(), TipoAlerta.DEADLINE, msg));
                    }
                }
            }
        }

        // 2. Pending Tasks Summary
        long pendingCount = listaTareas.stream().filter(t -> t.getEstado() == EstadoTarea.PENDING).count();
        if (pendingCount > 0) {
            String msg = "Tienes " + pendingCount + " tareas pendientes.";
            if (!alertaDAO.existeAlertaReciente(usuarioActual.getIdUsuario(), TipoAlerta.PENDING_TASKS, msg)) {
                alertaDAO.crear(new Alerta(usuarioActual.getIdUsuario(), TipoAlerta.PENDING_TASKS, msg));
            }
        }

        // 3. Team Membership (Simple check)
        List<Equipo> equipos = new EquipoDAO().listarEquiposPorUsuario(usuarioActual.getIdUsuario());
        if (!equipos.isEmpty()) {
            StringBuilder sb = new StringBuilder("Perteneces a los equipos: ");
            for (Equipo e : equipos)
                sb.append(e.getNombre()).append(", ");
            String msg = sb.substring(0, sb.length() - 2);
            if (!alertaDAO.existeAlertaReciente(usuarioActual.getIdUsuario(), TipoAlerta.TEAM_UPDATE, msg)) {
                alertaDAO.crear(new Alerta(usuarioActual.getIdUsuario(), TipoAlerta.TEAM_UPDATE, msg));
            }
        }
    }

    public void actualizarAvatarHeader() {
        if (usuarioActual != null && usuarioActual.getRutaImagen() != null) {
            java.io.File imgFile = new java.io.File(usuarioActual.getRutaImagen());
            if (imgFile.exists()) {
                javafx.scene.image.Image img = new javafx.scene.image.Image(imgFile.toURI().toString());
                headerAvatar.setFill(new javafx.scene.paint.ImagePattern(img));
            }
        }
    }

    @FXML
    public void initialize() {
        if (contentBorderPane != null) {
            kanbanView = contentBorderPane.getCenter();
        }
        setupDragAndDropColumns();

        if (searchField != null) {
            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                mostrarTareas();
            });
        }

        if (comboEquipos != null) {
            comboEquipos.setConverter(new javafx.util.StringConverter<Equipo>() {
                @Override
                public String toString(Equipo object) {
                    return object != null ? object.getNombre() : "Todos los Equipos";
                }

                @Override
                public Equipo fromString(String string) {
                    return null;
                }
            });
            comboEquipos.valueProperty().addListener((obs, oldVal, newVal) -> mostrarTareas());
        }

        if (comboProyectos != null) {
            comboProyectos.setConverter(new javafx.util.StringConverter<Proyecto>() {
                @Override
                public String toString(Proyecto object) {
                    return object != null ? object.getNombre() : "Todos los Proyectos";
                }

                @Override
                public Proyecto fromString(String string) {
                    return null;
                }
            });
            comboProyectos.valueProperty().addListener((obs, oldVal, newVal) -> mostrarTareas());
        }
    }

    private void actualizarSeleccionSidebar(Button botonSeleccionado) {
        // Remove selected class from all buttons
        if (btnInicio != null)
            btnInicio.getStyleClass().remove("sidebar-button-selected");
        if (btnPanelControl != null)
            btnPanelControl.getStyleClass().remove("sidebar-button-selected");
        if (btnMisTareas != null)
            btnMisTareas.getStyleClass().remove("sidebar-button-selected");
        if (btnProyectos != null)
            btnProyectos.getStyleClass().remove("sidebar-button-selected");
        if (btnReportes != null)
            btnReportes.getStyleClass().remove("sidebar-button-selected");
        if (btnEquipos != null)
            btnEquipos.getStyleClass().remove("sidebar-button-selected");
        if (btnAjustes != null)
            btnAjustes.getStyleClass().remove("sidebar-button-selected");

        // Add selected class to the clicked button
        if (botonSeleccionado != null && !botonSeleccionado.getStyleClass().contains("sidebar-button-selected")) {
            botonSeleccionado.getStyleClass().add("sidebar-button-selected");
        }
    }

    private void mostrarTareas() {
        vboxPendientes.getChildren().clear();
        vboxProgreso.getChildren().clear();
        vboxCompletadas.getChildren().clear();

        int countPendientes = 0;
        int countProgreso = 0;
        int countCompletadas = 0;

        for (Tarea tarea : listaTareas) {
            // Apply Filters
            boolean matchesSearch = true;
            if (searchField != null && searchField.getText() != null && !searchField.getText().isEmpty()) {
                String lowerCaseFilter = searchField.getText().toLowerCase();
                matchesSearch = tarea.getTitulo().toLowerCase().contains(lowerCaseFilter)
                        || (tarea.getDescripcion() != null
                                && tarea.getDescripcion().toLowerCase().contains(lowerCaseFilter));
            }

            boolean matchesDate = true;
            if (filtroHoy) {
                if (tarea.getFechaLimite() != null) {
                    matchesDate = tarea.getFechaLimite().toLocalDate().isEqual(java.time.LocalDate.now());
                } else {
                    matchesDate = false;
                }
            } else if (filtroVencidas) {
                if (tarea.getFechaLimite() != null) {
                    matchesDate = tarea.getFechaLimite().isBefore(java.time.LocalDateTime.now())
                            && tarea.getEstado() != EstadoTarea.COMPLETED;
                } else {
                    matchesDate = false;
                }
            } else if (fechaInicioFilter != null && fechaFinFilter != null && tarea.getFechaLimite() != null) {
                java.time.LocalDate tareaDate = tarea.getFechaLimite().toLocalDate();
                matchesDate = !tareaDate.isBefore(fechaInicioFilter) && !tareaDate.isAfter(fechaFinFilter);
            } else if ((fechaInicioFilter != null || fechaFinFilter != null) && tarea.getFechaLimite() == null) {
                matchesDate = false;
            }

            boolean matchesTeam = true;
            if (comboEquipos != null && comboEquipos.getValue() != null) {
                // Filter by team. Assuming tasks are linked to projects, and projects to teams.
                // Or if Tarea has idProyecto, check if that project belongs to the selected
                // team.
                // Since Tarea model has idProyecto, we need to check the project's team.
                // This might be expensive to check for every task if we don't have the project
                // loaded.
                // For now, let's assume we can check via the project list or if Tarea has
                // direct link.
                // Tarea has idProyecto. We can check if the project of this task belongs to the
                // selected team.
                // Optimally, we should have a map of ProjectId -> TeamId.
                // For simplicity, let's fetch the project for the task.
                if (tarea.getIdProyecto() != null) {
                    java.util.Optional<Proyecto> p = new ProyectoDAO().buscarPorId(tarea.getIdProyecto());
                    if (p.isPresent()) {
                        matchesTeam = p.get().getIdEquipo() != null
                                && p.get().getIdEquipo().equals(comboEquipos.getValue().getIdEquipo());
                    } else {
                        matchesTeam = false;
                    }
                } else {
                    matchesTeam = false;
                }
            }

            boolean matchesProject = true;
            if (comboProyectos != null && comboProyectos.getValue() != null) {
                matchesProject = tarea.getIdProyecto() != null
                        && tarea.getIdProyecto().equals(comboProyectos.getValue().getIdProyecto());
            }

            if (matchesSearch && matchesDate && matchesTeam && matchesProject) {
                VBox card = crearTarjetaTarea(tarea);

                switch (tarea.getEstado()) {
                    case PENDING:
                        vboxPendientes.getChildren().add(card);
                        countPendientes++;
                        break;
                    case IN_PROGRESS:
                        vboxProgreso.getChildren().add(card);
                        countProgreso++;
                        break;
                    case COMPLETED:
                        vboxCompletadas.getChildren().add(card);
                        countCompletadas++;
                        break;
                    default:
                        break;
                }
            }
        }

        lblCountPendientes.setText("(" + countPendientes + ")");
        lblCountProgreso.setText("(" + countProgreso + ")");
        lblCountCompletadas.setText("(" + countCompletadas + ")");
    }

    private VBox crearTarjetaTarea(Tarea tarea) {
        VBox card = new VBox();
        card.getStyleClass().add("kanban-card");
        card.setSpacing(10);

        // Title
        Label title = new Label(tarea.getTitulo());
        title.getStyleClass().add("task-title");
        title.setWrapText(true);

        // Tags Row (Priority + Date)
        HBox tags = new HBox(8);
        tags.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        Label priorityLabel = new Label();
        priorityLabel.getStyleClass().add("badge");
        switch (tarea.getPrioridad()) {
            case HIGH:
                priorityLabel.setText("Alta");
                priorityLabel.getStyleClass().add("badge-priority-high");
                break;
            case MEDIUM:
                priorityLabel.setText("Media");
                priorityLabel.getStyleClass().add("badge-priority-medium");
                break;
            case LOW:
                priorityLabel.setText("Baja");
                priorityLabel.getStyleClass().add("badge-priority-low");
                break;
            case URGENT:
                priorityLabel.setText("Urgente");
                priorityLabel.getStyleClass().add("badge-priority-high");
                break;
        }

        Label dateLabel = new Label();
        if (tarea.getFechaLimite() != null) {
            dateLabel.setText("📅 " + tarea.getFechaLimite().format(DateTimeFormatter.ofPattern("dd MMM")));
            dateLabel.setStyle("-fx-text-fill: #64748B; -fx-font-size: 11px;");
            if (tarea.getFechaLimite().isBefore(java.time.LocalDateTime.now())
                    && tarea.getEstado() != EstadoTarea.COMPLETED) {
                dateLabel.setStyle("-fx-text-fill: #EF4444; -fx-font-size: 11px; -fx-font-weight: bold;");
            }
        }

        tags.getChildren().addAll(priorityLabel, dateLabel);

        // Footer with Avatar and Actions
        HBox footer = new HBox(10);
        footer.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);

        // Action Buttons (Edit, Comment, Attach)
        Button btnEdit = new Button("✎");
        btnEdit.getStyleClass().add("icon-button-small");
        btnEdit.setOnAction(e -> abrirDetalleTarea(tarea));

        // Avatar Circle
        StackPane avatar = new StackPane();
        avatar.getStyleClass().add("avatar-circle");

        // Load creator's avatar
        boolean avatarLoaded = false;
        if (tarea.getCreadoPor() != null) {
            try {
                java.util.Optional<Usuario> creadorOpt = new UsuarioDAO().buscarPorId(tarea.getCreadoPor());
                if (creadorOpt.isPresent()) {
                    Usuario creador = creadorOpt.get();
                    if (creador.getRutaImagen() != null) {
                        java.io.File imgFile = new java.io.File(creador.getRutaImagen());
                        if (imgFile.exists()) {
                            javafx.scene.shape.Circle imgCircle = new javafx.scene.shape.Circle(12);
                            imgCircle.setFill(new javafx.scene.paint.ImagePattern(
                                    new javafx.scene.image.Image(imgFile.toURI().toString())));
                            avatar.getChildren().add(imgCircle);
                            avatarLoaded = true;
                        }
                    }
                    if (!avatarLoaded) {
                        Label initials = new Label(creador.getNombre().substring(0, 1).toUpperCase());
                        initials.getStyleClass().add("avatar-text");
                        avatar.getChildren().add(initials);
                        avatarLoaded = true;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!avatarLoaded) {
            Label initials = new Label("?");
            initials.getStyleClass().add("avatar-text");
            avatar.getChildren().add(initials);
        }

        // Spacer
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

        footer.getChildren().addAll(btnEdit, spacer, avatar);

        card.getChildren().addAll(title, tags, footer);

        // Drag & Drop - Source
        card.setOnDragDetected(event -> {
            javafx.scene.input.Dragboard db = card.startDragAndDrop(javafx.scene.input.TransferMode.MOVE);
            javafx.scene.input.ClipboardContent content = new javafx.scene.input.ClipboardContent();
            content.putString(String.valueOf(tarea.getIdTarea()));
            db.setContent(content);
            event.consume();
        });

        // Click Event - Open Modal
        card.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                abrirDetalleTarea(tarea);
            }
        });

        return card;
    }

    private void abrirDetalleTarea(Tarea tarea) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/administrador_tareas/Vista/DetalleTarea.fxml"));
            Parent root = loader.load();

            DetalleTareaController controller = loader.getController();
            controller.setDatos(tarea, usuarioActual);

            Stage stage = new Stage();
            stage.initOwner(btnMisTareas.getScene().getWindow());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setTitle("Detalles de la Tarea");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            if (controller.isGuardado()) {
                recargarTareasDesdeBD();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupDragAndDropColumns() {
        setupColumnDragHandlers(vboxPendientes, EstadoTarea.PENDING);
        setupColumnDragHandlers(vboxProgreso, EstadoTarea.IN_PROGRESS);
        setupColumnDragHandlers(vboxCompletadas, EstadoTarea.COMPLETED);
    }

    private void setupColumnDragHandlers(VBox column, EstadoTarea targetStatus) {
        column.setOnDragOver(event -> {
            if (event.getGestureSource() != column && event.getDragboard().hasString()) {
                event.acceptTransferModes(javafx.scene.input.TransferMode.MOVE);
            }
            event.consume();
        });

        column.setOnDragDropped(event -> {
            javafx.scene.input.Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasString()) {
                try {
                    Long taskId = Long.parseLong(db.getString());
                    Tarea task = listaTareas.stream()
                            .filter(t -> t.getIdTarea().equals(taskId))
                            .findFirst().orElse(null);

                    if (task != null && task.getEstado() != targetStatus) {
                        task.setEstado(targetStatus);
                        new TareaDAO().actualizarEstado(taskId, targetStatus);
                        recargarTareasDesdeBD();
                        success = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            event.setDropCompleted(success);
            event.consume();
        });
    }

    @FXML
    private void handleNuevaTarea(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/NuevaTarea.fxml"));
            Parent root = loader.load();

            NuevaTareaController controlador = loader.getController();
            controlador.setUsuarioId(usuarioActual.getIdUsuario());

            Stage stage = new Stage();
            stage.initOwner(btnNuevaTarea.getScene().getWindow());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setTitle("Nueva Tarea");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            Tarea nueva = controlador.getNuevaTarea();
            if (nueva != null) {
                usuarioActual.agregarTarea(nueva);
                listaTareas.add(nueva);
                mostrarTareas();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void recargarTareasDesdeBD() {
        try {
            listaTareas = new ArrayList<>(
                    new TareaDAO().listarPorUsuario(usuarioActual.getIdUsuario()));

            // Populate filters if not already done or need refresh
            if (comboEquipos != null && comboEquipos.getItems().isEmpty()) {
                List<Equipo> equipos = new EquipoDAO().listarEquiposPorUsuario(usuarioActual.getIdUsuario());
                comboEquipos.getItems().add(null); // Option for "All"
                comboEquipos.getItems().addAll(equipos);
            }

            if (comboProyectos != null && comboProyectos.getItems().isEmpty()) {
                // Ideally filter projects by user or team, but for now list all or user's
                // projects
                // Assuming ProyectoDAO has a method to list by user or we just list all for now
                List<Proyecto> proyectos = new ProyectoDAO().listarProyectos();
                comboProyectos.getItems().add(null); // Option for "All"
                comboProyectos.getItems().addAll(proyectos);
            }

            mostrarTareas();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleInicio(ActionEvent event) {
        try {
            if (kanbanView == null && contentBorderPane != null) {
                kanbanView = contentBorderPane.getCenter();
            }

            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Inicio.fxml"));
            Parent root = loader.load();

            InicioController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(root);
            }
            actualizarSeleccionSidebar(btnInicio);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handlePanelControl(ActionEvent event) {
        try {
            if (kanbanView == null && contentBorderPane != null) {
                kanbanView = contentBorderPane.getCenter();
            }

            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Dashboard.fxml"));
            Parent dashboardRoot = loader.load();

            DashboardController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(dashboardRoot);
            }
            actualizarSeleccionSidebar(btnPanelControl);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleProyectos(ActionEvent event) {
        try {
            if (kanbanView == null && contentBorderPane != null) {
                kanbanView = contentBorderPane.getCenter();
            }

            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Proyectos.fxml"));
            Parent root = loader.load();

            ProyectosController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(root);
            }
            actualizarSeleccionSidebar(btnProyectos);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleReportes(ActionEvent event) {
        try {
            if (kanbanView == null && contentBorderPane != null) {
                kanbanView = contentBorderPane.getCenter();
            }

            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Reportes.fxml"));
            Parent root = loader.load();

            ReportesController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(root);
            }
            actualizarSeleccionSidebar(btnReportes);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleNotificaciones(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/administrador_tareas/Vista/Notificaciones.fxml"));
            Parent root = loader.load();

            NotificacionesController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            javafx.stage.Popup popup = new javafx.stage.Popup();
            popup.getContent().add(root);
            popup.setAutoHide(true);

            javafx.geometry.Point2D point = btnNotificaciones.localToScreen(0, 0);
            popup.show(btnNotificaciones.getScene().getWindow(), point.getX() - 300 + btnNotificaciones.getWidth(),
                    point.getY() + btnNotificaciones.getHeight());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleActualizarTareas(ActionEvent event) {
        if (usuarioActual == null)
            return;

        if (contentBorderPane != null && kanbanView != null) {
            contentBorderPane.setCenter(kanbanView);
        }

        recargarTareasDesdeBD();

        actualizarSeleccionSidebar(btnMisTareas);
    }

    @FXML
    private void handleSalir(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();

        FXMLLoader loader = new FXMLLoader(getClass()
                .getResource("/com/example/administrador_tareas/Vista/Login.fxml"));
        Parent root = loader.load();

        Stage loginStage = new Stage();
        loginStage.setTitle("Login");
        loginStage.setScene(new Scene(root));
        loginStage.show();
    }

    @FXML
    private void handleVerArchivadas(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Archivados.fxml"));
            Parent root = loader.load();

            ArchivadoController ctrl = loader.getController();
            ctrl.setUsuario(usuarioActual);

            Stage st = new Stage();
            st.setTitle("Tareas Archivadas");
            st.initOwner(btnNuevaTarea.getScene().getWindow());
            st.initModality(Modality.WINDOW_MODAL);
            st.setScene(new Scene(root));
            st.showAndWait();

            recargarTareasDesdeBD();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void handleEquipos(ActionEvent event) {
        try {
            if (kanbanView == null && contentBorderPane != null) {
                kanbanView = contentBorderPane.getCenter();
            }

            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/Equipos.fxml"));
            Parent root = loader.load();

            EquiposController controller = loader.getController();
            controller.setUsuario(usuarioActual);

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(root);
            }
            actualizarSeleccionSidebar(btnEquipos);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAjustes(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/administrador_tareas/Vista/Configuracion.fxml"));
            Parent root = loader.load();

            ConfiguracionController controller = loader.getController();
            controller.setUsuario(usuarioActual);
            controller.setMainController(this); // Pass reference

            if (contentBorderPane != null) {
                contentBorderPane.setCenter(root);
            }
            actualizarSeleccionSidebar(btnAjustes);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRangoFecha(ActionEvent event) {
        // Create a custom popup for date range selection
        javafx.scene.control.ContextMenu contextMenu = new javafx.scene.control.ContextMenu();

        VBox content = new VBox(10);
        content.setStyle("-fx-padding: 10; -fx-background-color: white;");

        DatePicker dpInicio = new DatePicker(fechaInicioFilter);
        dpInicio.setPromptText("Fecha Inicio");

        DatePicker dpFin = new DatePicker(fechaFinFilter);
        dpFin.setPromptText("Fecha Fin");

        HBox buttons = new HBox(10);
        Button btnAplicar = new Button("Aplicar");
        btnAplicar.setStyle("-fx-background-color: #2563EB; -fx-text-fill: white;");
        Button btnLimpiar = new Button("Limpiar");

        buttons.getChildren().addAll(btnAplicar, btnLimpiar);
        content.getChildren().addAll(new Label("Desde:"), dpInicio, new Label("Hasta:"), dpFin, buttons);

        javafx.scene.control.CustomMenuItem item = new javafx.scene.control.CustomMenuItem(content);
        item.setHideOnClick(false);
        contextMenu.getItems().add(item);

        btnAplicar.setOnAction(e -> {
            fechaInicioFilter = dpInicio.getValue();
            fechaFinFilter = dpFin.getValue();
            filtroHoy = false;
            filtroVencidas = false;
            mostrarTareas();
            contextMenu.hide();
        });

        btnLimpiar.setOnAction(e -> {
            fechaInicioFilter = null;
            fechaFinFilter = null;
            dpInicio.setValue(null);
            dpFin.setValue(null);
            mostrarTareas();
            contextMenu.hide();
        });

        contextMenu.show(btnRangoFecha, javafx.geometry.Side.BOTTOM, 0, 0);
    }

    @FXML
    private void handleHoy(ActionEvent event) {
        filtroHoy = !filtroHoy;
        filtroVencidas = false; // Mutually exclusive
        fechaInicioFilter = null;
        fechaFinFilter = null;

        if (filtroHoy) {
            btnHoy.setStyle("-fx-background-color: #E2E8F0; -fx-border-color: #CBD5E1; -fx-border-radius: 6;");
            btnVencidas.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");
        } else {
            btnHoy.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");
        }
        mostrarTareas();
    }

    @FXML
    private void handleTodas(ActionEvent event) {
        filtroHoy = false;
        filtroVencidas = false;
        fechaInicioFilter = null;
        fechaFinFilter = null;

        btnHoy.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");
        btnVencidas.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");

        mostrarTareas();
    }

    @FXML
    private void handleVencidas(ActionEvent event) {
        filtroVencidas = !filtroVencidas;
        filtroHoy = false; // Mutually exclusive
        fechaInicioFilter = null;
        fechaFinFilter = null;

        if (filtroVencidas) {
            btnVencidas.setStyle(
                    "-fx-background-color: #FEE2E2; -fx-border-color: #FECACA; -fx-border-radius: 6; -fx-text-fill: #EF4444;");
            btnHoy.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");
        } else {
            btnVencidas.setStyle("-fx-background-color: transparent; -fx-border-color: #E2E8F0; -fx-border-radius: 6;");
        }
        mostrarTareas();
    }
}
