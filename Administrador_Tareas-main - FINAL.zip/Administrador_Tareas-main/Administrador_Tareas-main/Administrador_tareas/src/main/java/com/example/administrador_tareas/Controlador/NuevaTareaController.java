package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Modelo.TipoAlerta;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.PrioridadTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;

public class NuevaTareaController {
    @FXML
    private TextField txtTitulo;
    @FXML
    private TextArea txtDescripcion;
    @FXML
    private DatePicker dpFechaLimite;
    @FXML
    private ComboBox<PrioridadTarea> cmbPrioridad;
    @FXML
    private Button btnGuardar;
    @FXML
    private Button btnCancelar;

    private Tarea nuevaTarea;
    private Long usuarioId;

    public void setUsuarioId(Long id) {
        this.usuarioId = id;
    }

    public Tarea getNuevaTarea() {
        return nuevaTarea;
    }

    @FXML
    public void initialize() {
        cmbPrioridad.getItems().setAll(PrioridadTarea.values());
        cmbPrioridad.setValue(PrioridadTarea.MEDIUM); // Default

        cmbPrioridad.setConverter(new StringConverter<PrioridadTarea>() {
            @Override
            public String toString(PrioridadTarea object) {
                if (object == null)
                    return "";
                switch (object) {
                    case LOW:
                        return "Baja";
                    case MEDIUM:
                        return "Media";
                    case HIGH:
                        return "Alta";
                    case URGENT:
                        return "Urgente";
                    default:
                        return object.name();
                }
            }

            @Override
            public PrioridadTarea fromString(String string) {
                return null; // No editable
            }
        });
    }

    @FXML
    private void handleGuardar(ActionEvent event) {
        String titulo = txtTitulo.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        LocalDate fecha = dpFechaLimite.getValue();
        PrioridadTarea prioridad = cmbPrioridad.getValue();

        if (titulo.isEmpty() || descripcion.isEmpty() || fecha == null || prioridad == null) {
            mostrarAlerta("Todos los campos son obligatorios.");
            return;
        }

        try {
            // ① Insertar en BD y obtener el ID generado
            TareaDAO tareaDAO = new TareaDAO();
            Tarea t = new Tarea();
            t.setCreadoPor(usuarioId);
            t.setTitulo(titulo);
            t.setDescripcion(descripcion);
            t.setFechaLimite(fecha.atStartOfDay()); // Convert LocalDate to LocalDateTime
            t.setPrioridad(prioridad);
            t.setEstado(EstadoTarea.PENDING);
            t.setFechaCreacion(java.time.LocalDateTime.now());

            Long nuevoId = tareaDAO.insertar(t);

            if (nuevoId < 0) {
                mostrarAlerta("Error al crear la tarea");
                return;
            }

            // ② Crear el objeto Tarea ya con ID
            t.setIdTarea(nuevoId);
            nuevaTarea = t;

            // ③ Crear notificación de nueva tarea
            // Notify the creator (confirmation)
            AlertaDAO alertaDAO = new AlertaDAO();
            String msg = "Has creado la tarea: " + t.getTitulo();
            alertaDAO.crear(new Alerta(usuarioId, TipoAlerta.NEW_TASK, msg));

            // Ideally, if assigned to someone else or part of a team, notify them too.
            // For now, just notify the creator as confirmation.

            // ④ Cerrar la ventana
            Stage stage = (Stage) btnGuardar.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error al guardar la tarea: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancelar(ActionEvent event) {
        nuevaTarea = null; // no se crea nada
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }

    private void mostrarAlerta(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("Campos incompletos");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

}
