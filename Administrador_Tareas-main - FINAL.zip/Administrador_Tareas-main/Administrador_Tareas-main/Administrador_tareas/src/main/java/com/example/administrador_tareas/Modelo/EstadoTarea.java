package com.example.administrador_tareas.Modelo;

public enum EstadoTarea {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    ARCHIVED,
    CANCELED
}
