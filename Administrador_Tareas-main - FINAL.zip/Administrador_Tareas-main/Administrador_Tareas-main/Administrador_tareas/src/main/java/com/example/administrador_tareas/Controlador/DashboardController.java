package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.ArchivoAdjuntoDAO;
import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Modelo.ArchivoAdjunto;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

public class DashboardController {

    @FXML
    private Label lblTotalTareas;
    @FXML
    private Label lblTareasCompletadas;
    @FXML
    private Label lblTareasVencidas;
    @FXML
    private Label lblProductividad;
    @FXML
    private javafx.scene.layout.GridPane calendarGrid;
    @FXML
    private Label lblMonthYear;

    private Usuario usuarioActual;
    private TareaDAO tareaDAO;
    private ArchivoAdjuntoDAO archivoAdjuntoDAO;
    private java.time.YearMonth currentYearMonth;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.tareaDAO = new TareaDAO();
        this.archivoAdjuntoDAO = new ArchivoAdjuntoDAO();
        this.currentYearMonth = java.time.YearMonth.now();
        cargarDatos();
        drawCalendar();
    }

    private void cargarDatos() {
        if (usuarioActual == null)
            return;

        // KPIs
        int total = tareaDAO.contarTotal(usuarioActual.getIdUsuario());
        int completadas = tareaDAO.contarPorEstado(usuarioActual.getIdUsuario(), EstadoTarea.COMPLETED);
        int vencidas = tareaDAO.contarVencidas(usuarioActual.getIdUsuario());

        lblTotalTareas.setText(String.valueOf(total));
        lblTareasCompletadas.setText(String.valueOf(completadas));
        lblTareasVencidas.setText(String.valueOf(vencidas));

        if (total > 0) {
            double productividad = ((double) completadas / total) * 100;
            lblProductividad.setText(String.format("%.1f%%", productividad));
        } else {
            lblProductividad.setText("0%");
        }
    }

    private void drawCalendar() {
        calendarGrid.getChildren().clear();

        // Headers
        String[] days = { "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom" };
        for (int i = 0; i < days.length; i++) {
            Label label = new Label(days[i]);
            label.setStyle("-fx-font-weight: bold; -fx-text-fill: #64748B;");
            javafx.scene.layout.GridPane.setHalignment(label, javafx.geometry.HPos.CENTER);
            calendarGrid.add(label, i, 0);
        }

        lblMonthYear.setText(currentYearMonth.getMonth()
                .getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.getDefault()).toUpperCase() + " "
                + currentYearMonth.getYear());

        java.time.LocalDate calendarDate = java.time.LocalDate.of(currentYearMonth.getYear(),
                currentYearMonth.getMonth(), 1);
        // Adjust to start on Monday (1)
        int dayOfWeek = calendarDate.getDayOfWeek().getValue(); // 1=Mon, 7=Sun
        calendarDate = calendarDate.minusDays(dayOfWeek - 1);

        // Fetch all tasks for user
        java.util.List<Tarea> allTasks = new ArrayList<>();
        try {
            allTasks = tareaDAO.listarPorUsuario(usuarioActual.getIdUsuario());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int row = 1; row < 7; row++) {
            for (int col = 0; col < 7; col++) {
                javafx.scene.layout.VBox cell = new javafx.scene.layout.VBox(2);
                cell.setStyle("-fx-border-color: #E2E8F0; -fx-border-width: 1; -fx-padding: 5; -fx-background-color: " +
                        (calendarDate.getMonth() == currentYearMonth.getMonth() ? "white" : "#F8FAFC") + ";");

                Label dayLabel = new Label(String.valueOf(calendarDate.getDayOfMonth()));
                dayLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: " +
                        (calendarDate.equals(java.time.LocalDate.now()) ? "#2563EB" : "#1E293B") + ";");
                cell.getChildren().add(dayLabel);

                // Add tasks for this day
                java.time.LocalDate currentDate = calendarDate;
                allTasks.stream()
                        .filter(t -> t.getFechaLimite() != null && t.getFechaLimite().toLocalDate().equals(currentDate))
                        .forEach(t -> {
                            Label taskLabel = new Label(t.getTitulo());
                            taskLabel.setMaxWidth(Double.MAX_VALUE);
                            taskLabel.setStyle(getTaskStyle(t));
                            taskLabel.setTooltip(
                                    new Tooltip(t.getTitulo() + "\n" + t.getDescripcion() + "\n(Click para entregar)"));
                            taskLabel.setOnMouseClicked(e -> handleTaskClick(t));
                            cell.getChildren().add(taskLabel);
                        });

                calendarGrid.add(cell, col, row);
                calendarDate = calendarDate.plusDays(1);
            }
        }
    }

    private String getTaskStyle(Tarea t) {
        String baseStyle = "-fx-padding: 2 4; -fx-background-radius: 4; -fx-font-size: 10px; -fx-cursor: hand;";
        if (t.getEstado() == EstadoTarea.COMPLETED) {
            return baseStyle
                    + "-fx-background-color: #DCFCE7; -fx-text-fill: #166534; -fx-text-decoration: line-through;"; // Strikethrough
        }

        long daysUntil = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(),
                t.getFechaLimite().toLocalDate());

        if (daysUntil < 0) { // Overdue
            return baseStyle + "-fx-background-color: #FEE2E2; -fx-text-fill: #991B1B;";
        } else if (daysUntil <= 1) { // Due soon
            return baseStyle + "-fx-background-color: #FFEDD5; -fx-text-fill: #9A3412;";
        } else if (daysUntil <= 3) { // Upcoming
            return baseStyle + "-fx-background-color: #FEF9C3; -fx-text-fill: #854D0E;";
        } else { // Safe
            return baseStyle + "-fx-background-color: #DBEAFE; -fx-text-fill: #1E40AF;";
        }
    }

    private void handleTaskClick(Tarea t) {
        if (t.getEstado() == EstadoTarea.COMPLETED) {
            mostrarAlerta(Alert.AlertType.INFORMATION, "Tarea Completada", "Esta tarea ya ha sido entregada.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Entregar Tarea");
        alert.setHeaderText("Entregar: " + t.getTitulo());
        alert.setContentText("¿Deseas adjuntar un archivo y marcar esta tarea como completada?");

        ButtonType btnAdjuntar = new ButtonType("Adjuntar y Entregar");
        ButtonType btnCancelar = new ButtonType("Cancelar", javafx.scene.control.ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(btnAdjuntar, btnCancelar);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == btnAdjuntar) {
            subirTarea(t);
        }
    }

    private void subirTarea(Tarea t) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Archivo de Tarea");
        File file = fileChooser.showOpenDialog(lblTotalTareas.getScene().getWindow());

        if (file != null) {
            try {
                // Create directory
                Path uploadDir = Paths.get("task_uploads");
                if (!Files.exists(uploadDir)) {
                    Files.createDirectories(uploadDir);
                }

                // Copy file
                String fileName = "task_" + t.getIdTarea() + "_" + System.currentTimeMillis() + "_" + file.getName();
                Path targetPath = uploadDir.resolve(fileName);
                Files.copy(file.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

                // Save attachment record
                ArchivoAdjunto adjunto = new ArchivoAdjunto();
                adjunto.setIdTarea(t.getIdTarea());
                adjunto.setNombreArchivo(file.getName());
                adjunto.setRutaArchivo(targetPath.toString());
                adjunto.setTipoMime(Files.probeContentType(targetPath));
                adjunto.setEsImagen(adjunto.getTipoMime() != null && adjunto.getTipoMime().startsWith("image"));
                adjunto.setSubidoPor(usuarioActual.getIdUsuario());

                archivoAdjuntoDAO.insertar(adjunto);

                // Mark task as completed
                tareaDAO.actualizarEstado(t.getIdTarea(), EstadoTarea.COMPLETED);

                mostrarAlerta(Alert.AlertType.INFORMATION, "Éxito", "Tarea entregada correctamente.");

                // Refresh
                cargarDatos();
                drawCalendar();

            } catch (IOException | SQLException e) {
                e.printStackTrace();
                mostrarAlerta(Alert.AlertType.ERROR, "Error", "No se pudo subir la tarea: " + e.getMessage());
            }
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handlePrevMonth() {
        currentYearMonth = currentYearMonth.minusMonths(1);
        drawCalendar();
    }

    @FXML
    private void handleNextMonth() {
        currentYearMonth = currentYearMonth.plusMonths(1);
        drawCalendar();
    }
}
