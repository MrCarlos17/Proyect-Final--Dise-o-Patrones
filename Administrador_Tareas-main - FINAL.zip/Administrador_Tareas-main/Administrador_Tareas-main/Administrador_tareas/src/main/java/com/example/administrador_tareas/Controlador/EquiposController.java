package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EquiposController {

    @FXML
    private TableView<Equipo> tablaEquipos;
    @FXML
    private TableColumn<Equipo, String> colNombre;
    @FXML
    private TableColumn<Equipo, String> colDescripcion;
    @FXML
    private TableColumn<Equipo, String> colFecha;
    @FXML
    private TableColumn<Equipo, Void> colAcciones;

    private Usuario usuarioActual;
    private EquipoDAO equipoDAO;

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        this.equipoDAO = new EquipoDAO();
        inicializarTabla();
        cargarEquipos();
    }

    private void inicializarTabla() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        colFecha.setCellValueFactory(cellData -> new SimpleStringProperty(
                cellData.getValue().getFechaCreacion().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));

        colAcciones.setCellFactory(param -> new TableCell<>() {
            private final Button btnEditar = new Button("Editar");
            private final Button btnMiembros = new Button("Miembros");
            private final HBox pane = new HBox(10, btnEditar, btnMiembros);

            {
                btnEditar.getStyleClass().add("button-secondary-small");
                btnMiembros.getStyleClass().add("button-secondary-small");

                btnEditar.setOnAction(event -> {
                    Equipo equipo = getTableView().getItems().get(getIndex());
                    handleEditarEquipo(equipo);
                });

                btnMiembros.setOnAction(event -> {
                    Equipo equipo = getTableView().getItems().get(getIndex());
                    handleGestionarMiembros(equipo);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(pane);
                }
            }
        });
    }

    private void cargarEquipos() {
        List<Equipo> equipos = equipoDAO.listarEquipos();
        tablaEquipos.setItems(FXCollections.observableArrayList(equipos));
    }

    @FXML
    private void handleNuevoEquipo(ActionEvent event) {
        abrirFormularioEquipo(null);
    }

    private void handleEditarEquipo(Equipo equipo) {
        abrirFormularioEquipo(equipo);
    }

    private void abrirFormularioEquipo(Equipo equipo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/NuevoEquipo.fxml"));
            Parent root = loader.load();

            NuevoEquipoController controller = loader.getController();
            if (equipo != null) {
                controller.setEquipo(equipo);
            }

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(tablaEquipos.getScene().getWindow());
            stage.setTitle(equipo == null ? "Nuevo Equipo" : "Editar Equipo");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

            cargarEquipos();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleGestionarMiembros(Equipo equipo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass()
                    .getResource("/com/example/administrador_tareas/Vista/GestionarMiembros.fxml"));
            Parent root = loader.load();

            GestionarMiembrosController controller = loader.getController();
            controller.setEquipo(equipo);

            Stage stage = new Stage();
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(tablaEquipos.getScene().getWindow());
            stage.setTitle("Gestionar Miembros - " + equipo.getNombre());
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
