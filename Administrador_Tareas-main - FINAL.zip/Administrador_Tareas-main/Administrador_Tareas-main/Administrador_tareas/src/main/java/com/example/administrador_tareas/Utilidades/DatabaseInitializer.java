package com.example.administrador_tareas.Utilidades;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {

    public static void initialize() {
        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement()) {

            // 1. Check/Add 'mensaje' column to 'alertas'
            if (!columnExists(conn, "alertas", "mensaje")) {
                stmt.execute("ALTER TABLE alertas ADD COLUMN mensaje TEXT");
                System.out.println("Columna 'mensaje' agregada a 'alertas'.");
            }

            // 2. Check/Add 'leida' column
            if (!columnExists(conn, "alertas", "leida")) {
                stmt.execute("ALTER TABLE alertas ADD COLUMN leida BOOLEAN DEFAULT FALSE");
                System.out.println("Columna 'leida' agregada a 'alertas'.");
            }

            // 3. Check/Add 'fecha_creacion' column
            if (!columnExists(conn, "alertas", "fecha_creacion")) {
                stmt.execute("ALTER TABLE alertas ADD COLUMN fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
                System.out.println("Columna 'fecha_creacion' agregada a 'alertas'.");
            }

            // 4. Check/Add 'fecha_envio' column
            if (!columnExists(conn, "alertas", "fecha_envio")) {
                stmt.execute("ALTER TABLE alertas ADD COLUMN fecha_envio TIMESTAMP");
                System.out.println("Columna 'fecha_envio' agregada a 'alertas'.");
            }

            // 5. Check/Add 'id_usuario' column
            if (!columnExists(conn, "alertas", "id_usuario")) {
                stmt.execute("ALTER TABLE alertas ADD COLUMN id_usuario INTEGER REFERENCES usuarios(id_usuario)");
                System.out.println("Columna 'id_usuario' agregada a 'alertas'.");
            }

            // 6. Ensure 'tipo_alerta' uses the enum or text.
            try {
                stmt.execute("ALTER TYPE tipo_alerta_enum ADD VALUE IF NOT EXISTS 'DEADLINE'");
                stmt.execute("ALTER TYPE tipo_alerta_enum ADD VALUE IF NOT EXISTS 'PENDING_TASKS'");
                stmt.execute("ALTER TYPE tipo_alerta_enum ADD VALUE IF NOT EXISTS 'TEAM_UPDATE'");
                stmt.execute("ALTER TYPE tipo_alerta_enum ADD VALUE IF NOT EXISTS 'NEW_COMMENT'");
                stmt.execute("ALTER TYPE tipo_alerta_enum ADD VALUE IF NOT EXISTS 'NEW_TASK'");
            } catch (SQLException e) {
                System.out.println(
                        "Nota: No se pudo actualizar el enum tipo_alerta_enum (puede que no exista o ya tenga los valores).");
            }

            // 7. Make 'id_tarea' nullable if it exists
            if (columnExists(conn, "alertas", "id_tarea")) {
                try {
                    stmt.execute("ALTER TABLE alertas ALTER COLUMN id_tarea DROP NOT NULL");
                    System.out.println("Restricción NOT NULL eliminada de 'id_tarea' en 'alertas'.");
                } catch (SQLException e) {
                    System.out
                            .println("Nota: No se pudo modificar 'id_tarea' (quizás ya es nullable o no es Postgres).");
                }
            }

            // 8. Make 'fecha_alerta' nullable if it exists
            if (columnExists(conn, "alertas", "fecha_alerta")) {
                try {
                    stmt.execute("ALTER TABLE alertas ALTER COLUMN fecha_alerta DROP NOT NULL");
                    System.out.println("Restricción NOT NULL eliminada de 'fecha_alerta' en 'alertas'.");
                } catch (SQLException e) {
                    System.out.println("Nota: No se pudo modificar 'fecha_alerta' (quizás ya es nullable).");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean columnExists(Connection conn, String tableName, String columnName) throws SQLException {
        try (ResultSet rs = conn.getMetaData().getColumns(null, null, tableName, columnName)) {
            return rs.next();
        }
    }
}
