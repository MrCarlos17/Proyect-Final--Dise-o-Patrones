package com.example.administrador_tareas.Modelo;

public enum PrioridadTarea {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
