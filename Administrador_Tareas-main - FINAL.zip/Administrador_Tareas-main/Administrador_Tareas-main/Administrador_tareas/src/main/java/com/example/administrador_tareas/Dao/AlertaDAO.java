package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Modelo.TipoAlerta;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;
import com.example.administrador_tareas.Utilidades.EmailService;
import com.example.administrador_tareas.Modelo.ConfiguracionNotificaciones;
import com.example.administrador_tareas.Modelo.Usuario;
import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Dao.ConfiguracionNotificacionesDAO;
import com.example.administrador_tareas.Utilidades.EmailTemplates;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AlertaDAO {

    public void crear(Alerta alerta) {
        String sql = "INSERT INTO alertas (id_usuario, tipo_alerta, mensaje, leida, fecha_creacion, fecha_envio) VALUES (?, ?::tipo_alerta_enum, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setLong(1, alerta.getIdUsuario());
            pstmt.setString(2, alerta.getTipoAlerta().name());
            pstmt.setString(3, alerta.getMensaje());
            pstmt.setBoolean(4, alerta.isLeida());
            pstmt.setTimestamp(5, Timestamp.valueOf(alerta.getFechaCreacion()));
            pstmt.setTimestamp(6, alerta.getFechaEnvio() != null ? Timestamp.valueOf(alerta.getFechaEnvio()) : null);

            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    alerta.setIdAlerta(generatedKeys.getLong(1));
                }
            }

            // Send email notification asynchronously
            enviarEmailNotificacion(alerta);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Alerta> listarPorUsuario(Long idUsuario) {
        List<Alerta> alertas = new ArrayList<>();
        String sql = "SELECT * FROM alertas WHERE id_usuario = ? ORDER BY fecha_creacion DESC LIMIT 20";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, idUsuario);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Alerta alerta = new Alerta();
                    alerta.setIdAlerta(rs.getLong("id_alerta"));
                    alerta.setIdUsuario(rs.getLong("id_usuario"));
                    alerta.setTipoAlerta(TipoAlerta.valueOf(rs.getString("tipo_alerta")));
                    alerta.setMensaje(rs.getString("mensaje"));
                    alerta.setLeida(rs.getBoolean("leida"));
                    alerta.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                    if (rs.getTimestamp("fecha_envio") != null) {
                        alerta.setFechaEnvio(rs.getTimestamp("fecha_envio").toLocalDateTime());
                    }
                    alertas.add(alerta);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alertas;
    }

    public void marcarComoLeida(Long idAlerta) {
        String sql = "UPDATE alertas SET leida = TRUE WHERE id_alerta = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idAlerta);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int contarNoLeidas(Long idUsuario) {
        String sql = "SELECT COUNT(*) FROM alertas WHERE id_usuario = ? AND leida = FALSE";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idUsuario);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean existeAlertaReciente(Long idUsuario, TipoAlerta tipo, String mensaje) {
        // Check for duplicate alert in the last 24 hours
        String sql = "SELECT COUNT(*) FROM alertas WHERE id_usuario = ? AND tipo_alerta = ?::tipo_alerta_enum AND mensaje = ? AND fecha_creacion > NOW() - INTERVAL '24 HOURS'";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idUsuario);
            pstmt.setString(2, tipo.name());
            pstmt.setString(3, mensaje);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Alerta> listarNoEnviadas(Long idUsuario) {
        List<Alerta> alertas = new ArrayList<>();
        String sql = "SELECT * FROM alertas WHERE id_usuario = ? AND fecha_envio IS NULL ORDER BY fecha_creacion ASC";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idUsuario);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Alerta alerta = new Alerta();
                    alerta.setIdAlerta(rs.getLong("id_alerta"));
                    alerta.setIdUsuario(rs.getLong("id_usuario"));
                    alerta.setTipoAlerta(TipoAlerta.valueOf(rs.getString("tipo_alerta")));
                    alerta.setMensaje(rs.getString("mensaje"));
                    alerta.setLeida(rs.getBoolean("leida"));
                    alerta.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                    // fecha_envio is null
                    alertas.add(alerta);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alertas;
    }

    public void marcarComoEnviada(Long idAlerta) {
        String sql = "UPDATE alertas SET fecha_envio = NOW() WHERE id_alerta = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setLong(1, idAlerta);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enviarEmailNotificacion(Alerta alerta) {
        new Thread(() -> {
            try {
                ConfiguracionNotificacionesDAO configDAO = new ConfiguracionNotificacionesDAO();
                ConfiguracionNotificaciones config = configDAO.obtenerPorUsuario(alerta.getIdUsuario());

                // If config doesn't exist, assume defaults (usually true for emails) or create
                // one.
                boolean shouldSend = (config != null && config.isRecibirEmails());

                // If config is null, assume true for now.
                if (config == null)
                    shouldSend = true;

                if (shouldSend) {
                    UsuarioDAO usuarioDAO = new UsuarioDAO();
                    Optional<Usuario> usuarioOpt = usuarioDAO.buscarPorId(alerta.getIdUsuario());

                    if (usuarioOpt.isPresent()) {
                        Usuario usuario = usuarioOpt.get();
                        if (usuario.getCorreo() != null) {
                            String asunto = EmailTemplates.obtenerAsunto(alerta.getTipoAlerta());
                            String cuerpo = EmailTemplates.generarHtmlNotificacion(asunto, alerta.getMensaje(),
                                    alerta.getTipoAlerta());
                            EmailService.enviarCorreo(usuario.getCorreo(), asunto, cuerpo);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
