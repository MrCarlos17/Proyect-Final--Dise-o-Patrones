package com.example.administrador_tareas.Modelo;

public enum EstadoUsuario {
    ACTIVO,
    INACTIVO
}
