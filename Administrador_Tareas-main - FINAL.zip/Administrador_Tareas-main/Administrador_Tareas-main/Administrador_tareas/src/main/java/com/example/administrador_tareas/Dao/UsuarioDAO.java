package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.EstadoUsuario;
import com.example.administrador_tareas.Modelo.Usuario;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.Optional;

public class UsuarioDAO {

    // Registrar usuario nuevo
    public Long registrar(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nombre, correo, clave_hash, id_rol, estado, ruta_imagen) " +
                "VALUES (?, ?, ?, ?, ?::estado_usuario_enum, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getClave());
            if (usuario.getIdRol() != null) {
                ps.setLong(4, usuario.getIdRol());
            } else {
                ps.setNull(4, Types.BIGINT);
            }
            ps.setString(5, usuario.getEstado() != null ? usuario.getEstado().name() : EstadoUsuario.ACTIVO.name());
            ps.setString(6, usuario.getRutaImagen());

            int filas = ps.executeUpdate();
            if (filas == 0) {
                throw new SQLException("No se pudo insertar el usuario");
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    Long idGenerado = rs.getLong(1);
                    usuario.setIdUsuario(idGenerado);
                    return idGenerado;
                }
            }
        }
        return -1L;
    }

    // Buscar usuario para login (por correo + clave)
    public Optional<Usuario> login(String correo, String clave) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE correo = ? AND clave_hash = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, correo);
            ps.setString(2, clave);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearUsuario(rs));
                }
            }
        }
        return Optional.empty();
    }

    public Optional<Usuario> buscarPorId(Long id) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE id_usuario = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearUsuario(rs));
                }
            }
        }
        return Optional.empty();
    }

    private Usuario mapearUsuario(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setIdUsuario(rs.getLong("id_usuario"));
        u.setNombre(rs.getString("nombre"));
        u.setCorreo(rs.getString("correo"));
        u.setClave(rs.getString("clave_hash"));
        u.setIdRol(rs.getObject("id_rol") != null ? rs.getLong("id_rol") : null);
        u.setEstado(EstadoUsuario.valueOf(rs.getString("estado")));
        u.setRutaImagen(rs.getString("ruta_imagen"));

        Timestamp ultimoAcceso = rs.getTimestamp("ultimo_acceso");
        if (ultimoAcceso != null)
            u.setUltimoAcceso(ultimoAcceso.toLocalDateTime());

        Timestamp fechaReg = rs.getTimestamp("fecha_registro");
        if (fechaReg != null)
            u.setFechaRegistro(fechaReg.toLocalDateTime());

        Timestamp fechaAct = rs.getTimestamp("fecha_actualizacion");
        if (fechaAct != null)
            u.setFechaActualizacion(fechaAct.toLocalDateTime());

        return u;
    }

    public boolean actualizar(Usuario usuario) throws SQLException {
        String sql = "UPDATE usuarios SET nombre = ?, correo = ?, clave_hash = ?, ruta_imagen = ? WHERE id_usuario = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getClave());
            ps.setString(4, usuario.getRutaImagen());
            ps.setLong(5, usuario.getIdUsuario());

            return ps.executeUpdate() > 0;
        }
    }

    public java.util.List<Usuario> listarUsuarios() {
        java.util.List<Usuario> usuarios = new java.util.ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                usuarios.add(mapearUsuario(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }
}
