package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.Comentario;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComentarioDAO {

    public void insertar(Comentario comentario) throws SQLException {
        String sql = "INSERT INTO comentarios_tarea (id_tarea, id_usuario, contenido, fecha_creacion) VALUES (?, ?, ?, NOW())";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, comentario.getIdTarea());
            ps.setLong(2, comentario.getIdUsuario());
            ps.setString(3, comentario.getContenido());

            ps.executeUpdate();
        }
    }

    public List<Comentario> listarPorTarea(Long idTarea) throws SQLException {
        String sql = "SELECT c.*, u.nombre as nombre_usuario " +
                "FROM comentarios_tarea c " +
                "JOIN usuarios u ON c.id_usuario = u.id_usuario " +
                "WHERE c.id_tarea = ? " +
                "ORDER BY c.fecha_creacion DESC";

        List<Comentario> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idTarea);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Comentario c = new Comentario();
                    c.setIdComentario(rs.getLong("id_comentario"));
                    c.setIdTarea(rs.getLong("id_tarea"));
                    c.setIdUsuario(rs.getLong("id_usuario"));
                    c.setContenido(rs.getString("contenido"));
                    c.setFechaCreacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
                    c.setNombreUsuario(rs.getString("nombre_usuario"));
                    lista.add(c);
                }
            }
        }
        return lista;
    }
}
