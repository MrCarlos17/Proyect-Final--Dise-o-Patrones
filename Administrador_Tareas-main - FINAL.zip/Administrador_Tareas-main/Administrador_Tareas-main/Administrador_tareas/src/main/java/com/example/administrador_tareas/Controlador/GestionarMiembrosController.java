package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.EquipoDAO;
import com.example.administrador_tareas.Dao.UsuarioDAO;
import com.example.administrador_tareas.Dao.AlertaDAO;
import com.example.administrador_tareas.Modelo.Alerta;
import com.example.administrador_tareas.Modelo.TipoAlerta;
import com.example.administrador_tareas.Modelo.Equipo;
import com.example.administrador_tareas.Modelo.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.sql.SQLException;
import java.util.List;

public class GestionarMiembrosController {

    @FXML
    private Label lblTitulo;
    @FXML
    private ComboBox<Usuario> cmbUsuarios;
    @FXML
    private ListView<Usuario> listaMiembros;

    private Equipo equipo;
    private EquipoDAO equipoDAO;
    private UsuarioDAO usuarioDAO;

    @FXML
    public void initialize() {
        equipoDAO = new EquipoDAO();
        usuarioDAO = new UsuarioDAO();
        cargarUsuariosDisponibles();
        setupListView();
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
        lblTitulo.setText("Miembros - " + equipo.getNombre());
        cargarMiembros();
    }

    private void cargarUsuariosDisponibles() {
        List<Usuario> usuarios = usuarioDAO.listarUsuarios(); // Assuming this method exists
        cmbUsuarios.getItems().addAll(usuarios);

        // Custom cell factory to show names in ComboBox
        cmbUsuarios.setCellFactory(param -> new ListCell<Usuario>() {
            @Override
            protected void updateItem(Usuario item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getNombre() + " (" + item.getCorreo() + ")");
                }
            }
        });
        cmbUsuarios.setButtonCell(cmbUsuarios.getCellFactory().call(null));
    }

    private void cargarMiembros() {
        if (equipo != null) {
            List<Usuario> miembros = equipoDAO.listarMiembros(equipo.getIdEquipo());
            listaMiembros.getItems().setAll(miembros);
        }
    }

    private void setupListView() {
        listaMiembros.setCellFactory(param -> new ListCell<Usuario>() {
            private final Button btnEliminar = new Button("❌");
            private final HBox pane = new HBox(10);
            private final Label lblNombre = new Label();

            {
                btnEliminar.setStyle("-fx-background-color: transparent; -fx-text-fill: red; -fx-cursor: hand;");
                btnEliminar.setOnAction(event -> {
                    Usuario usuario = getItem();
                    handleEliminar(usuario);
                });
                pane.getChildren().addAll(lblNombre, new javafx.scene.layout.Region(), btnEliminar);
                javafx.scene.layout.HBox.setHgrow(pane.getChildren().get(1), javafx.scene.layout.Priority.ALWAYS);
            }

            @Override
            protected void updateItem(Usuario item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                } else {
                    lblNombre.setText(item.getNombre() + " (" + item.getCorreo() + ")");
                    setGraphic(pane);
                }
            }
        });
    }

    @FXML
    private void handleAgregar(ActionEvent event) {
        Usuario usuarioSeleccionado = cmbUsuarios.getValue();
        if (usuarioSeleccionado != null && equipo != null) {
            try {
                // Check if already member
                boolean exists = listaMiembros.getItems().stream()
                        .anyMatch(u -> u.getIdUsuario().equals(usuarioSeleccionado.getIdUsuario()));

                if (exists) {
                    mostrarAlerta("Información", "El usuario ya es miembro del equipo.");
                    return;
                }

                equipoDAO.agregarMiembro(equipo.getIdEquipo(), usuarioSeleccionado.getIdUsuario());
                cargarMiembros();

                // Notification for new member
                AlertaDAO alertaDAO = new AlertaDAO();
                String msg = "Has sido añadido al equipo: " + equipo.getNombre();
                alertaDAO.crear(new Alerta(usuarioSeleccionado.getIdUsuario(), TipoAlerta.TEAM_UPDATE, msg));

                cmbUsuarios.setValue(null);
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo agregar el miembro: " + e.getMessage());
            }
        }
    }

    private void handleEliminar(Usuario usuario) {
        if (equipo != null) {
            try {
                equipoDAO.eliminarMiembro(equipo.getIdEquipo(), usuario.getIdUsuario());
                cargarMiembros();
            } catch (SQLException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo eliminar el miembro: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCerrar(ActionEvent event) {
        Stage stage = (Stage) lblTitulo.getScene().getWindow();
        stage.close();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
