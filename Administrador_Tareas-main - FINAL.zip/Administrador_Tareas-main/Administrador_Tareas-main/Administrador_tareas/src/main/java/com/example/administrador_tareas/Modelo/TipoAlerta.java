package com.example.administrador_tareas.Modelo;

public enum TipoAlerta {
    VENCIMIENTO,
    NUEVA_TAREA,
    COMENTARIO,
    CAMBIO_ESTADO,
    DEADLINE,
    PENDING_TASKS,
    TEAM_UPDATE,
    NEW_COMMENT,
    NEW_TASK
}
