package com.example.administrador_tareas.Dao;

import com.example.administrador_tareas.Modelo.ArchivoAdjunto;
import com.example.administrador_tareas.Utilidades.DatabaseConnection;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;

public class ArchivoAdjuntoDAO {

    public Long insertar(ArchivoAdjunto adjunto) throws SQLException {
        String sql = "INSERT INTO archivos_adjuntos " +
                "(id_tarea, nombre_archivo, ruta_archivo, tipo_mime, es_imagen, subido_por, fecha_subida) " +
                "VALUES (?, ?, ?, ?, ?, ?, NOW())";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setLong(1, adjunto.getIdTarea());
            ps.setString(2, adjunto.getNombreArchivo());
            ps.setString(3, adjunto.getRutaArchivo());
            ps.setString(4, adjunto.getTipoMime());
            ps.setBoolean(5, adjunto.isEsImagen());
            if (adjunto.getSubidoPor() != null) {
                ps.setLong(6, adjunto.getSubidoPor());
            } else {
                ps.setNull(6, Types.BIGINT);
            }

            int filas = ps.executeUpdate();
            if (filas == 0) {
                throw new SQLException("No se pudo insertar el archivo adjunto");
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    Long idGenerado = rs.getLong(1);
                    adjunto.setIdArchivo(idGenerado);
                    return idGenerado;
                }
            }
        }
        return -1L;
    }

    public List<ArchivoAdjunto> listarPorTarea(Long idTarea) throws SQLException {
        String sql = "SELECT id_archivo, id_tarea, nombre_archivo, ruta_archivo, " +
                "tipo_mime, es_imagen, subido_por, fecha_subida " +
                "FROM archivos_adjuntos WHERE id_tarea = ?";

        List<ArchivoAdjunto> lista = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idTarea);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearAdjunto(rs));
                }
            }
        }
        return lista;
    }

    public boolean eliminar(Long idArchivo) throws SQLException {
        String sql = "DELETE FROM archivos_adjuntos WHERE id_archivo = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idArchivo);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminarPorTarea(Long idTarea) throws SQLException {
        String sql = "DELETE FROM archivos_adjuntos WHERE id_tarea = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, idTarea);
            return ps.executeUpdate() > 0;
        }
    }

    private ArchivoAdjunto mapearAdjunto(ResultSet rs) throws SQLException {
        ArchivoAdjunto a = new ArchivoAdjunto();
        a.setIdArchivo(rs.getLong("id_archivo"));
        a.setIdTarea(rs.getLong("id_tarea"));
        a.setNombreArchivo(rs.getString("nombre_archivo"));
        a.setRutaArchivo(rs.getString("ruta_archivo"));
        a.setTipoMime(rs.getString("tipo_mime"));
        a.setEsImagen(rs.getBoolean("es_imagen"));
        a.setSubidoPor(rs.getObject("subido_por") != null ? rs.getLong("subido_por") : null);

        Timestamp fSubida = rs.getTimestamp("fecha_subida");
        if (fSubida != null) {
            a.setFechaSubida(fSubida.toLocalDateTime());
        }
        return a;
    }
}
