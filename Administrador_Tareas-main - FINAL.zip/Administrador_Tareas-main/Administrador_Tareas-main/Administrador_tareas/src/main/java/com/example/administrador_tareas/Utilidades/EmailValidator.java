package com.example.administrador_tareas.Utilidades;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class EmailValidator {

    private static final String ABSTRACT_API_KEY = "d14097ba1a3e48d585e0f0a395deab55";
    private static final String API_URL = "https://emailvalidation.abstractapi.com/v1/?api_key=" + ABSTRACT_API_KEY
            + "&email=";

    private static final Set<String> ALLOW_SMTP_BYPASS_DOMAINS = new HashSet<>(Arrays.asList(
            "gmail.com", "googlemail.com", "hotmail.com", "outlook.com", "live.com", "msn.com",
            "yahoo.com", "icloud.com", "me.com", "proton.me", "protonmail.com", "utp.edu.pe"));

    private static final Set<String> DISPOSABLE_DOMAINS = new HashSet<>(Arrays.asList(
            "tempmail.com", "guerrillamail.com", "10minutemail.com", "throwaway.email",
            "mailinator.com", "trashmail.com", "yopmail.com", "maildrop.cc", "temp-mail.org",
            "fakeinbox.com", "sharklasers.com", "getnada.com", "mohmal.com", "mintemail.com",
            "dispostable.com", "emailondeck.com", "tempinbox.com", "spamgourmet.com"));

    // Basic regex for format
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public static ValidationResult validate(String email) {
        if (email == null || email.trim().isEmpty()) {
            return new ValidationResult(false, "Email vacío");
        }

        email = email.trim().toLowerCase();

        // 1. Basic Format
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            return new ValidationResult(false, "Formato de correo inválido");
        }

        if (!email.contains("@")) {
            return new ValidationResult(false, "Email debe contener @");
        }

        String[] parts = email.split("@");
        if (parts.length != 2) {
            return new ValidationResult(false, "Formato inválido");
        }
        String local = parts[0];
        String domain = parts[1];

        // 2. Local Part Length
        if (local.length() < 5) {
            return new ValidationResult(false, "El nombre de usuario es muy corto (mínimo 5 caracteres)");
        }
        if (local.length() > 64) {
            return new ValidationResult(false, "El nombre de usuario es muy largo");
        }

        // 3. Disposable Domains
        if (DISPOSABLE_DOMAINS.contains(domain)) {
            return new ValidationResult(false, "Correo desechable no permitido");
        }

        // 4. API Validation
        // Only call API if not in bypass list (or if we want to verify existence even
        // for major providers?
        // The PHP script says: "verified" => in_array($domain,
        // $ALLOW_SMTP_BYPASS_DOMAINS, true) ? null : true
        // It seems it skips API for bypass domains? No, the PHP script calls API if
        // enable_api_validation is true.
        // But let's follow the user's PHP logic: it calls API.

        try {
            return validateWithApi(email, domain);
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback if API fails: assume valid if format is okay
            return new ValidationResult(true, "Válido (API no disponible)");
        }
    }

    private static ValidationResult validateWithApi(String email, String domain) {
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + email))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                Gson gson = new Gson();
                JsonObject json = gson.fromJson(response.body(), JsonObject.class);

                boolean isValidFormat = json.get("is_valid_format").getAsJsonObject().get("value").getAsBoolean();
                boolean isMxFound = json.get("is_mx_found").getAsJsonObject().get("value").getAsBoolean();
                boolean isSmtpValid = json.get("is_smtp_valid").getAsJsonObject().get("value").getAsBoolean();
                boolean isDisposable = json.get("is_disposable_email").getAsJsonObject().get("value").getAsBoolean();
                double qualityScore = json.get("quality_score").getAsDouble();

                if (!isValidFormat)
                    return new ValidationResult(false, "Formato inválido según API");
                if (isDisposable)
                    return new ValidationResult(false, "Correo desechable detectado por API");
                if (!isMxFound)
                    return new ValidationResult(false, "Dominio sin registros MX");

                boolean smtpBypass = ALLOW_SMTP_BYPASS_DOMAINS.contains(domain);
                if (!smtpBypass && !isSmtpValid) {
                    return new ValidationResult(false, "Servidor SMTP no acepta este correo");
                }

                if (qualityScore < 0.6) {
                    return new ValidationResult(false, "Baja confiabilidad (score: " + qualityScore + ")");
                }

                return new ValidationResult(true, "Correo verificado");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // If API fails or throws, default to valid to not block user
        return new ValidationResult(true, "Válido (Verificación API falló)");
    }

    public static class ValidationResult {
        public boolean valid;
        public String message;

        public ValidationResult(boolean valid, String message) {
            this.valid = valid;
            this.message = message;
        }
    }
}
