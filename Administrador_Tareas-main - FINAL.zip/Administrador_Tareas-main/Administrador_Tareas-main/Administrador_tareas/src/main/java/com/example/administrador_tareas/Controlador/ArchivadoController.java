package com.example.administrador_tareas.Controlador;

import com.example.administrador_tareas.Dao.TareaDAO;
import com.example.administrador_tareas.Modelo.EstadoTarea;
import com.example.administrador_tareas.Modelo.Tarea;
import com.example.administrador_tareas.Modelo.Usuario;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class ArchivadoController {
    @FXML
    private ListView<Tarea> listViewArchivadas;
    private Usuario usuarioActual;
    private List<Tarea> tareasArchivadas = new ArrayList<>();
    private TareaController parent;

    public void setParentController(TareaController parent) {
        this.parent = parent;
    }

    public void initialize() {
        listViewArchivadas.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    public void setUsuario(Usuario usuario) {
        this.usuarioActual = usuario;
        cargarArchivadas();
    }

    private void cargarArchivadas() {
        try {
            tareasArchivadas = new TareaDAO()
                    .listarArchivadasPorUsuario(usuarioActual.getIdUsuario());
            listViewArchivadas.getItems().setAll(tareasArchivadas);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleVolver(ActionEvent e) {
        ((Stage) listViewArchivadas.getScene().getWindow()).close();
    }

    @FXML
    private void handleEliminarArchivada(ActionEvent e) {
        Tarea seleccion = listViewArchivadas.getSelectionModel().getSelectedItem();
        if (seleccion != null) {
            try {
                new TareaDAO().eliminarLogico(seleccion.getIdTarea());
                listViewArchivadas.getItems().remove(seleccion);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @FXML
    private void handleDesarchivar(ActionEvent e) {
        Tarea seleccion = listViewArchivadas.getSelectionModel().getSelectedItem();
        if (seleccion != null) {
            try {
                seleccion.setEstado(EstadoTarea.PENDING);
                new TareaDAO().actualizarEstado(seleccion.getIdTarea(), EstadoTarea.PENDING);
                listViewArchivadas.getItems().remove(seleccion);

                // Actualizar la vista principal:
                if (parent != null) {
                    parent.recargarTareasDesdeBD();
                }

                // Luego cierra la ventana
                ((Stage) listViewArchivadas.getScene().getWindow()).close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}
