package com.example.administrador_tareas.Utilidades;

import com.example.administrador_tareas.Modelo.TipoAlerta;

public class EmailTemplates {

    public static String generarHtmlNotificacion(String titulo, String mensaje, TipoAlerta tipo) {
        String colorHeader = "#4A90E2"; // Default Blue
        String icono = "🔔";

        if (tipo != null) {
            switch (tipo) {
                case DEADLINE:
                    colorHeader = "#D0021B"; // Red
                    icono = "⏰";
                    break;
                case NEW_TASK:
                    colorHeader = "#7ED321"; // Green
                    icono = "📋";
                    break;
                case NEW_COMMENT:
                    colorHeader = "#F5A623"; // Orange
                    icono = "💬";
                    break;
                case TEAM_UPDATE:
                    colorHeader = "#9013FE"; // Purple
                    icono = "👥";
                    break;
                case PENDING_TASKS:
                    colorHeader = "#F8E71C"; // Yellow
                    icono = "⚠️";
                    break;
                default:
                    break;
            }
        }

        return """
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
                        .container { max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden; }
                        .header { background-color: %s; color: #ffffff; padding: 20px; text-align: center; font-size: 24px; font-weight: bold; }
                        .content { padding: 30px; color: #333333; line-height: 1.6; font-size: 16px; }
                        .footer { background-color: #eeeeee; padding: 15px; text-align: center; font-size: 12px; color: #777777; }
                        .btn { display: inline-block; background-color: %s; color: #ffffff; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 20px; font-weight: bold; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            %s %s
                        </div>
                        <div class="content">
                            <p>Hola,</p>
                            <p>%s</p>
                            <p>Por favor, revisa la aplicación para más detalles.</p>
                            <center><a href="#" class="btn">Ir a la Aplicación</a></center>
                        </div>
                        <div class="footer">
                            &copy; 2025 TaskFlow. Todos los derechos reservados.<br>
                            Este es un mensaje automático, por favor no responder.
                        </div>
                    </div>
                </body>
                </html>
                """
                .formatted(colorHeader, colorHeader, icono, titulo, mensaje);
    }

    public static String obtenerAsunto(TipoAlerta tipo) {
        if (tipo == null)
            return "Nueva Notificación - TaskFlow";

        return switch (tipo) {
            case DEADLINE -> "URGENTE: Tarea próxima a vencer";
            case NEW_TASK -> "Nueva tarea asignada";
            case NEW_COMMENT -> "Nuevo comentario en tu tarea";
            case TEAM_UPDATE -> "Actualización de equipo";
            case PENDING_TASKS -> "Recordatorio: Tareas pendientes";
            default -> "Notificación de TaskFlow";
        };
    }
}
